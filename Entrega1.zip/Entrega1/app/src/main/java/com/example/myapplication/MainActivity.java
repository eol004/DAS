package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private View pantallaJ1;
    private View pantallaJ2;
    private ImageView caballoJ1;
    private ImageView caballoJ2;
    private View divisor;
    private Button boton_j1;
    private Button boton_j2;
    private int posJ1 = 0;
    private int posJ2=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Jugadores
        pantallaJ1 = findViewById(R.id.pantalla_j1);
        pantallaJ2 = findViewById(R.id.pantalla_j2);
        //Caballos
        caballoJ1 = findViewById(R.id.caballoJ1);
        caballoJ2 = findViewById(R.id.caballoJ2);
        //divisor
        divisor = findViewById(R.id.divisor);
        //Botones
        boton_j1 = findViewById(R.id.boton_j1);
        boton_j2 = findViewById(R.id.boton_j2);

        boton_j1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Obtener la posicion del caballo
                int[] posC = new int[2]; //Array para posiciones X e Y
                caballoJ1.getLocationOnScreen(posC); //se guarda en posC la posicion actual del caballo
                //Obtener la posicion del divisor
                int[] posDiv = new int[2];
                divisor.getLocationOnScreen(posDiv);
                posJ1 = posJ1 + 10; // mover hacia abajo
                //delimitar para que no vaya más alla del divisor
                if (posC[1] <= posDiv[1] && posC[1] - caballoJ1.getHeight() <= posDiv[1]) {
                    caballoJ1.setY(posJ1);
                }
            }
        });

        boton_j2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] posC = new int[2];
                caballoJ2.getLocationOnScreen(posC);

                int[] posDiv = new int[2];
                divisor.getLocationOnScreen(posDiv);

                System.out.println("altura pos del caballo: " +posC[1]);
                System.out.println("posJ2 del caballo: " +posJ2);
                System.out.println("Tamaño del caballo: " +caballoJ2.getHeight());
                System.out.println("Altura del divisor: " +posDiv[1]);
                posJ2 -= 1;

                if (posJ2 + caballoJ2.getHeight() < posDiv[1]) {
                    caballoJ2.setY(posJ2);
                }
                else{
                    System.out.println("FIN");
                }
            }
        });
    }
}
