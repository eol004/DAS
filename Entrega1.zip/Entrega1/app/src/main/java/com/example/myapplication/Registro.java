package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

public class Registro extends AppCompatActivity {

}
